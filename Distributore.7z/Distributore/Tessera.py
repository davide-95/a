class Tessera():
    def __init__(self, Codice, Credito):
        self.codice = Codice
        self.credito = Credito
