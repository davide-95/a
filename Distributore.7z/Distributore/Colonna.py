class Colonna:
    pass
